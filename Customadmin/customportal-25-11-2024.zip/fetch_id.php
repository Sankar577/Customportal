<?php

$host = 'localhost';
$username = 'uqdggrqf_custom';
$password = 'custom123@';
$dbname = 'uqdggrqf_Custom_Portal';
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    $stmt = $conn->prepare("SELECT 
            cm.customer_name,
            cpm.product_name,
            cpm.product_id,
            crm.Rental_End_Date,
            crm.Rental_Start_Date,
            crm.Total_Rental_Amount
        FROM
         custom_rental_management crm
        INNER JOIN
           custom_product_management cpm 
        INNER JOIN
           custom_customer cm 
        WHERE cpm.product_id = ?");
     
    $stmt->bind_param("s", $product_id); 
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Check if a product is found
    if ($result->num_rows > 0) {
        
        $row = $result->fetch_assoc();
        $product_data = [
            'product_id' => $row['product_id'],
            'product_name' => $row['product_name'],
            'customer_name' => $row['customer_name'],
            'Rental_Start_Date' => $row['Rental_Start_Date'],
            'Rental_End_Date' => $row['Rental_End_Date'],
            'Total_Rental_Amount' => $row['Total_Rental_Amount']
        ];

        echo json_encode($product_data);
    } else {
        echo json_encode(["message" => "No product found for this ID."]);
    }

    $stmt->close();
}

$conn->close();
?>
