<?php

$host = 'localhost';
$username = 'uqdggrqf_custom';
$password = 'custom123@';
$dbname = 'uqdggrqf_Custom_Portal';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_GET['sku'])) {
    $sku = $_GET['sku'];

    $sku = $conn->real_escape_string($sku);

    
    $sql = "SELECT * FROM custom_product_management WHERE Stock_keeping_unit = '$sku' LIMIT 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row); 
    } else {
        echo json_encode([]);  
    }
} else {
    echo json_encode([]);  
}

$conn->close();
?>
