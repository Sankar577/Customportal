<?php
$host = 'localhost';
$username = 'uqdggrqf_custom';
$password = 'custom123@';
$dbname = 'uqdggrqf_Custom_Portal';


$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    $stmt = $conn->prepare("SELECT 
            cpm.product_name,
            cpm.product_id,
            cpm.Product_price
        FROM
         custom_expense_management crm
        INNER JOIN
           custom_product_management cpm 
        WHERE cpm.product_id = ?");
     
    $stmt->bind_param("s", $product_id); 
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Check if a product is found
    if ($result->num_rows > 0) {
        
        $row = $result->fetch_assoc();
        $product_data = [
            'product_id' => $row['product_id'],
            'product_name' => $row['product_name'],
            'Product_price' => $row['Product_price'],
           
        ];

        echo json_encode($product_data);
    } else {
        echo json_encode(["message" => "No product found for this ID."]);
    }

    $stmt->close();
}

$conn->close();
?>
