<?php
$host = 'localhost';
$username = 'uqdggrqf_custom';
$password = 'custom123@';
$dbname = 'uqdggrqf_Custom_Portal';


$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);}

if (isset($_POST['product_name'])) {
    $product_name = $_POST['product_name'];

    // Sanitize the input
    $product_name = $conn->real_escape_string($product_name);

    
    $sql = "SELECT * FROM custom_product_management WHERE product_name LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = "%" . $product_name . "%";  // Add wildcard for partial match
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the results
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }

    // Return the results in JSON format
    echo json_encode([
        'status' => 'success',
        'products' => $products
    ]);

    $stmt->close();
    $conn->close();
}
?>
