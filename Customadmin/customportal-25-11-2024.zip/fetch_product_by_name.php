<?php
include("../lib/config.php"); 

// Ensure the database connection is valid
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// $sql = "SELECT * FROM custom_product_management WHERE product_name LIKE '%$product_name%' ";

if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];

//     $product_name = $conn->real_escape_string($product_name);

    
    $sql = "SELECT * FROM custom_product_management WHERE product_id = '$product_id'";
   
    $res = $db_cms->select_query($sql);

}
    echo json_encode($res); 
   

?>
